export const ROUTES = {
    HOMEPAGE_ROUTE: '/'
}